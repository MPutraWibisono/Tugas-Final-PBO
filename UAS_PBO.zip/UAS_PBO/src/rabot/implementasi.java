package rabot;

abstract class implementasi {
    public String password;

    public void setPassword(String pass) {
        this.password = pass;
    }
    public String getPassword() {
        return password;
    }
    
    public abstract String jargon();
}

class implementasi2 extends implementasi{
    
    @Override
    public String jargon(){
        return "Selamat Datang di Toko Perabotan WIBI JAYA";
    }
}
